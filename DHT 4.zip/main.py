print("Senson de temperatura")
from machine import Pin
import machine
import dht
import time

LED_B = Pin(14,Pin.OUT)
LED_R = Pin(12,Pin.OUT)

leitura_anterior_T = 0;
leitura_anterior_U=0;

sensor = dht.DHT22(machine.Pin(16))

while True:
    sensor.measure()
    time.sleep(1)
    if sensor.humidity() > 50:
        LED_R.value(1)
    else: 
        LED_R.value(0)
    if sensor.humidity() < 20:
        LED_B.value(1)
    else:
        LED_B.value(0)

    #imprimindo os dados

    if((leitura_anterior_T != sensor.temperature()) or (leitura_anterior_U != sensor.humidity())):
        print("A temperatura atual é: ",sensor.temperature())
        print("A umidade atual é: ",sensor.humidity())
        leitura_anterior_T = sensor.temperature()
        leitura_anterior_U = sensor.humidity()

    else:
        print("Sem alterações")    
